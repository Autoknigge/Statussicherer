package de.statussicherer

import android.app.Activity
import android.app.Dialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.Settings
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowInsetsController
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

class MainActivity : Activity() {

    companion object {
        private val DEFAULT_BG = Color.parseColor("#0D1218")
        private val ACCENT = Color.parseColor("#3D5AFE")
        private val PRESETS = intArrayOf(
            Color.parseColor("#0D1218"), Color.parseColor("#000000"),
            Color.parseColor("#22262B"), Color.parseColor("#0B1F3A"),
            Color.parseColor("#10261C"), Color.parseColor("#2B1218"),
            Color.parseColor("#24142E"), Color.parseColor("#F4F6F9"),
            Color.parseColor("#FBF3E4"), Color.parseColor("#E3F4EC"),
            Color.parseColor("#E3EEF9"), Color.parseColor("#F9E6EC")
        )
        private const val REQ_TREE = 42
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    // Farben werden aus der gewählten Hintergrundfarbe berechnet (siehe applyTheme)
    private var BG = DEFAULT_BG
    private var SURFACE = Color.parseColor("#1B2531")
    private var SURFACE2 = Color.parseColor("#2A3745")
    private var INK = Color.parseColor("#E7ECF2")
    private var MUTED = Color.parseColor("#9AA8B8")

    private lateinit var prefs: SharedPreferences
    private val main = Handler(Looper.getMainLooper())
    private val scanPool = Executors.newSingleThreadExecutor()
    private val thumbPool = Executors.newFixedThreadPool(3)
    private val cache = LruCache<String, Bitmap>(200)

    private var all: List<StatusFile> = emptyList()
    private var shown: List<StatusFile> = emptyList()
    private var filter = 0 // 0 = alle, 1 = Bilder, 2 = Videos
    private val selected = HashSet<String>()
    private val saved: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private var saving = false
    private var progress: String? = null

    private lateinit var statusText: TextView
    private lateinit var emptyBox: ScrollView
    private lateinit var contentBox: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var noneText: TextView
    private lateinit var hintText: TextView
    private lateinit var grid: GridView
    private lateinit var chips: List<TextView>
    private lateinit var btnSel: Button
    private lateinit var btnNew: Button
    private val tileAdapter = TileAdapter()

    // ------------------------------------------------------------------ Aufbau

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("status-sicherer", MODE_PRIVATE)
        applyTheme(prefs.getInt("bg", DEFAULT_BG))
        saved.addAll(prefs.getStringSet("saved", emptySet()) ?: emptySet())

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
        }
        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleRow.addView(text("Status-Sicherer", 26f, INK, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        val colorBtn = text("Farbe", 14f, ACCENT, true)
        colorBtn.setPadding(dp(12), dp(8), dp(12), dp(8))
        colorBtn.setOnClickListener { showColorDialog() }
        titleRow.addView(colorBtn)
        header.addView(titleRow)
        statusText = text("Suche Status-Dateien …", 13f, MUTED)
        header.addView(statusText)
        root.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        // Einrichtung, solange noch kein Zugriff besteht
        emptyBox = ScrollView(this)
        val emptyIn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(24))
        }
        emptyIn.addView(text("Einmal Zugriff erlauben", 18f, INK, true))
        emptyIn.addView(
            text(
                "Damit die App WhatsApp und WhatsApp Business automatisch erkennt, braucht sie einmal Zugriff auf die Dateien. Danach findet sie die Status-Ordner von selbst.",
                14f, MUTED
            ),
            lp(6)
        )
        emptyIn.addView(button("Zugriff auf alle Dateien erlauben", true) { openAllFilesSettings() }, lp(16))
        emptyIn.addView(
            text(
                "Android öffnet eine Einstellungsseite. Schalte dort den Zugriff für Status-Sicherer ein und gehe mit „Zurück“ zur App.",
                13f, MUTED
            ),
            lp(8)
        )
        emptyIn.addView(text("Alternative: nur einen Ordner freigeben", 15f, INK, true), lp(28))
        emptyIn.addView(button("WhatsApp-Ordner wählen", false) { pickTree("com.whatsapp", "WhatsApp") }, lp(8))
        emptyIn.addView(
            button("WhatsApp-Business-Ordner wählen", false) { pickTree("com.whatsapp.w4b", "WhatsApp Business") },
            lp(8)
        )
        emptyIn.addView(
            text("Tippe im Auswahlfenster unten auf „Diesen Ordner verwenden“ und bestätige mit „Zulassen“.", 13f, MUTED),
            lp(8)
        )
        emptyIn.addView(
            text(
                "Die App hat keine Internetberechtigung. Sie liest nur die Status-Ordner und legt Kopien in der Galerie ab. Speichere und teile nur Inhalte, für die du die Erlaubnis hast.",
                13f, MUTED
            ),
            lp(28)
        )
        emptyBox.addView(emptyIn)
        emptyBox.visibility = View.GONE

        // Übersicht
        contentBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        val chipRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(8))
        }
        chips = listOf(chip("Alle", 0), chip("Bilder", 1), chip("Videos", 2))
        for (c in chips) {
            chipRow.addView(c, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        }
        chipRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val reload = text("Neu laden", 14f, ACCENT)
        reload.setPadding(dp(8), dp(8), dp(8), dp(8))
        reload.setOnClickListener { refresh() }
        chipRow.addView(reload)
        contentBox.addView(chipRow, LinearLayout.LayoutParams(MATCH, WRAP))

        hintText = text("Antippen wählt aus, lange drücken zeigt die Vorschau.", 12f, MUTED)
        hintText.setPadding(dp(16), 0, dp(16), dp(6))
        contentBox.addView(hintText, LinearLayout.LayoutParams(MATCH, WRAP))

        noneText = text("", 14f, MUTED)
        noneText.setPadding(dp(16), dp(16), dp(16), dp(16))
        noneText.visibility = View.GONE
        contentBox.addView(noneText, LinearLayout.LayoutParams(MATCH, WRAP))

        grid = GridView(this).apply {
            numColumns = (resources.configuration.screenWidthDp / 120).coerceAtLeast(3)
            horizontalSpacing = dp(6)
            verticalSpacing = dp(6)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            setPadding(dp(10), dp(4), dp(10), dp(12))
            clipToPadding = false
            selector = ColorDrawable(Color.TRANSPARENT)
            adapter = tileAdapter
            setOnItemClickListener { _, _, pos, _ -> toggle(shown[pos]) }
            setOnItemLongClickListener { _, _, pos, _ ->
                preview(shown[pos])
                true
            }
        }
        contentBox.addView(grid, LinearLayout.LayoutParams(MATCH, 0, 1f))

        root.addView(contentBox, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(emptyBox, LinearLayout.LayoutParams(MATCH, 0, 1f))

        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(SURFACE)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            visibility = View.GONE
        }
        btnSel = button("Auswahl speichern (0)", false) {
            saveFiles(all.filter { selected.contains(it.key) })
        }
        btnNew = button("Alle neuen speichern", true) {
            saveFiles(all.filter { !saved.contains(it.key) })
        }
        btnSel.textSize = 14f
        btnNew.textSize = 14f
        bottomBar.addView(btnSel, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(8) })
        bottomBar.addView(btnNew, LinearLayout.LayoutParams(0, WRAP, 1f))
        root.addView(bottomBar, LinearLayout.LayoutParams(MATCH, WRAP))

        setContentView(root)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        val lightBars = brightness(BG) >= 0.5f
        val barMask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
            WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        window.insetsController?.setSystemBarsAppearance(if (lightBars) barMask else 0, barMask)
        styleChips()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ------------------------------------------------------------------ Suchen

    private fun refresh() {
        statusText.text = "Suche Status-Dateien …"
        scanPool.execute {
            val found = ArrayList<StatusFile>()
            var access = false
            val allFiles = Environment.isExternalStorageManager()
            if (allFiles) {
                access = true
                found.addAll(Finder.scanFiles())
            }
            val trees = prefs.getStringSet("trees", emptySet()) ?: emptySet()
            for (t in trees) {
                try {
                    val u = Uri.parse(t)
                    val ok = contentResolver.persistedUriPermissions.any { it.uri == u && it.isReadPermission }
                    if (ok) {
                        access = true
                        found.addAll(Finder.scanTree(this, u))
                    }
                } catch (e: Exception) {
                    // Freigabe nicht mehr gültig: ignorieren
                }
            }
            val list = found.distinctBy { it.key }.sortedByDescending { it.modified }
            val diag = if (list.isEmpty() && allFiles) Finder.diagnose() else ""
            main.post { onScan(list, access, diag) }
        }
    }

    private fun onScan(list: List<StatusFile>, access: Boolean, diag: String) {
        all = list
        selected.retainAll(list.map { it.key }.toSet())
        emptyBox.visibility = if (access) View.GONE else View.VISIBLE
        contentBox.visibility = if (access) View.VISIBLE else View.GONE
        bottomBar.visibility = if (access && list.isNotEmpty()) View.VISIBLE else View.GONE

        val fresh = list.count { !saved.contains(it.key) }
        statusText.text = when {
            !access -> "Zugriff fehlt noch"
            list.isEmpty() -> "Keine Status gefunden"
            else -> {
                val names = list.map { it.source }.distinct().joinToString(" und ")
                val word = if (list.size == 1) "Datei" else "Dateien"
                "${list.size} $word aus $names · $fresh neu"
            }
        }

        var none = if (list.isEmpty()) {
            "Sieh dir zuerst einen Status in WhatsApp an. Danach erscheint er hier."
        } else {
            "In dieser Ansicht gibt es nichts."
        }
        if (list.isEmpty() && diag.isNotEmpty()) none += "\n\nGeprüfte Ordner:\n$diag"
        noneText.text = none
        applyFilter()
    }

    private fun applyFilter() {
        shown = all.filter { filter == 0 || (filter == 1 && !it.isVideo) || (filter == 2 && it.isVideo) }
        noneText.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
        hintText.visibility = if (shown.isEmpty()) View.GONE else View.VISIBLE
        tileAdapter.notifyDataSetChanged()
        styleChips()
        updateBar()
    }

    private fun styleChips() {
        for ((i, c) in chips.withIndex()) {
            val on = i == filter
            c.background = rounded(if (on) ACCENT else SURFACE, dp(20))
            c.setTextColor(if (on) Color.WHITE else MUTED)
        }
    }

    // ------------------------------------------------------------------ Zugriff

    private fun openAllFilesSettings() {
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
        }
    }

    private fun pickTree(pkg: String, folder: String) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        val initial = DocumentsContract.buildDocumentUri(
            "com.android.externalstorage.documents",
            "primary:Android/media/$pkg/$folder/Media/.Statuses"
        )
        i.putExtra(DocumentsContract.EXTRA_INITIAL_URI, initial)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(i, REQ_TREE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_TREE || resultCode != RESULT_OK) return
        val u = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
            // wird beim nächsten Suchlauf geprüft
        }
        val set = HashSet<String>(prefs.getStringSet("trees", emptySet()) ?: emptySet())
        set.add(u.toString())
        prefs.edit().putStringSet("trees", set).apply()
        refresh()
    }

    // ------------------------------------------------------------------ Auswahl und Speichern

    private fun toggle(f: StatusFile) {
        if (!selected.add(f.key)) selected.remove(f.key)
        tileAdapter.notifyDataSetChanged()
        updateBar()
    }

    private fun updateBar() {
        val fresh = all.count { !saved.contains(it.key) }
        val sel = selected.size
        btnSel.text = if (saving) (progress ?: "Speichere …") else "Auswahl speichern ($sel)"
        btnNew.text = if (saving) "Bitte warten …" else "Alle neuen speichern ($fresh)"
        enabledLook(btnSel, !saving && sel > 0)
        enabledLook(btnNew, !saving && fresh > 0)
    }

    private fun enabledLook(b: Button, on: Boolean) {
        b.isEnabled = on
        b.alpha = if (on) 1f else 0.45f
    }

    private fun saveFiles(list: List<StatusFile>) {
        if (saving || list.isEmpty()) return
        saving = true
        progress = "Speichere 0/${list.size}"
        updateBar()
        scanPool.execute {
            var ok = 0
            var fail = 0
            for ((i, f) in list.withIndex()) {
                try {
                    copyToGallery(f)
                    saved.add(f.key)
                    ok++
                } catch (e: Exception) {
                    fail++
                }
                main.post {
                    progress = "Speichere ${i + 1}/${list.size}"
                    updateBar()
                }
            }
            prefs.edit().putStringSet("saved", HashSet<String>(saved)).apply()
            main.post {
                saving = false
                progress = null
                selected.clear()
                tileAdapter.notifyDataSetChanged()
                updateBar()
                val msg = StringBuilder()
                msg.append("$ok gespeichert. Du findest sie in der Galerie im Ordner „Status-Sicherer“.")
                if (fail > 0) msg.append(" $fail konnten nicht gespeichert werden.")
                toast(msg.toString())
            }
        }
    }

    private fun mimeFor(ext: String, video: Boolean): String = when (ext) {
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "webp" -> "image/webp"
        "gif" -> "image/gif"
        "mp4" -> "video/mp4"
        "3gp" -> "video/3gpp"
        "webm" -> "video/webm"
        "mkv" -> "video/x-matroska"
        else -> if (video) "video/mp4" else "image/jpeg"
    }

    private fun copyToGallery(f: StatusFile) {
        val stamp = SimpleDateFormat("yyyy-MM-dd_HHmmss", Locale.GERMANY).format(Date(f.modified))
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "Status_$stamp.${f.ext}")
            put(MediaStore.MediaColumns.MIME_TYPE, mimeFor(f.ext, f.isVideo))
            put(
                MediaStore.MediaColumns.RELATIVE_PATH,
                if (f.isVideo) "Movies/Status-Sicherer" else "Pictures/Status-Sicherer"
            )
            put(MediaStore.MediaColumns.DATE_TAKEN, f.modified)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val collection: Uri = if (f.isVideo) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        }
        val resolver = contentResolver
        val target = resolver.insert(collection, values) ?: throw IOException("Eintrag nicht möglich")
        try {
            val input = resolver.openInputStream(f.uri) ?: throw IOException("Lesen nicht möglich")
            val output = resolver.openOutputStream(target) ?: throw IOException("Schreiben nicht möglich")
            input.use { i -> output.use { o -> i.copyTo(o) } }
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            resolver.update(target, done, null, null)
        } catch (e: Exception) {
            resolver.delete(target, null, null)
            throw e
        }
    }

    // ------------------------------------------------------------------ Vorschau

    private fun preview(f: StatusFile) {
        val dlg = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val box = FrameLayout(this)
        box.setBackgroundColor(Color.BLACK)
        var video: VideoView? = null

        if (f.isVideo) {
            val vv = VideoView(this)
            val mc = MediaController(this)
            mc.setAnchorView(vv)
            vv.setMediaController(mc)
            vv.setVideoURI(f.uri)
            vv.setOnPreparedListener { mp ->
                mp.isLooping = true
                vv.start()
            }
            box.addView(vv, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))
            video = vv
        } else {
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            box.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
            thumbPool.execute {
                val b = try {
                    decodeSampled(f.uri, 1600)
                } catch (e: Exception) {
                    null
                }
                main.post { if (b != null) iv.setImageBitmap(b) }
            }
        }

        val close = text("✕", 22f, Color.WHITE, true)
        close.setPadding(dp(18), dp(14), dp(18), dp(14))
        close.setOnClickListener { dlg.dismiss() }
        box.addView(close, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END))

        val save = button("In Galerie speichern", true) {
            dlg.dismiss()
            saveFiles(listOf(f))
        }
        val saveLp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        saveLp.bottomMargin = dp(if (f.isVideo) 90 else 24)
        box.addView(save, saveLp)

        dlg.setOnDismissListener { video?.stopPlayback() }
        dlg.setContentView(box)
        dlg.show()
    }

    // ------------------------------------------------------------------ Kacheln

    private inner class TileAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val tile = (convertView as? Tile) ?: Tile(this@MainActivity)
            tile.bind(shown[position])
            return tile
        }
    }

    private inner class Tile(ctx: Context) : FrameLayout(ctx) {
        private val img = ImageView(ctx)
        private val info = TextView(ctx)
        private val mark = TextView(ctx)
        private val badge = TextView(ctx)
        private val frame: Drawable = GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            setStroke(dp(3), ACCENT)
        }

        init {
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            img.setBackgroundColor(SURFACE)
            addView(img, FrameLayout.LayoutParams(MATCH, MATCH))

            info.textSize = 11f
            info.setTextColor(Color.WHITE)
            info.setBackgroundColor(Color.argb(150, 0, 0, 0))
            info.setPadding(dp(6), dp(3), dp(6), dp(3))
            addView(info, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))

            mark.textSize = 14f
            mark.setTextColor(Color.WHITE)
            mark.gravity = Gravity.CENTER
            val markLp = FrameLayout.LayoutParams(dp(26), dp(26), Gravity.TOP or Gravity.START)
            markLp.setMargins(dp(8), dp(8), 0, 0)
            addView(mark, markLp)

            badge.text = "▶"
            badge.textSize = 12f
            badge.setTextColor(Color.WHITE)
            badge.background = rounded(Color.argb(150, 0, 0, 0), dp(6))
            badge.setPadding(dp(8), dp(3), dp(8), dp(3))
            val badgeLp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END)
            badgeLp.setMargins(0, dp(8), dp(8), 0)
            addView(badge, badgeLp)
        }

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            val w = MeasureSpec.getSize(widthMeasureSpec)
            super.onMeasure(
                widthMeasureSpec,
                MeasureSpec.makeMeasureSpec((w * 1.25f).toInt(), MeasureSpec.EXACTLY)
            )
        }

        fun bind(f: StatusFile) {
            val age = System.currentTimeMillis() - f.modified
            val second = if (saved.contains(f.key)) "✓ gespeichert" else expiryText(age)
            info.text = ageText(age) + " · " + sizeText(f.size) + "\n" + second
            val sel = selected.contains(f.key)
            mark.text = if (sel) "✓" else ""
            mark.background = circle(if (sel) ACCENT else Color.argb(140, 0, 0, 0))
            foreground = if (sel) frame else null
            badge.visibility = if (f.isVideo) View.VISIBLE else View.GONE
            loadThumb(f, img)
        }
    }

    private fun loadThumb(f: StatusFile, view: ImageView) {
        view.tag = f.key
        val cached = cache.get(f.key)
        if (cached != null) {
            view.setImageBitmap(cached)
            return
        }
        view.setImageDrawable(null)
        thumbPool.execute {
            val bmp = try {
                makeThumb(f)
            } catch (e: Exception) {
                null
            }
            if (bmp != null) {
                cache.put(f.key, bmp)
                main.post { if (view.tag == f.key) view.setImageBitmap(bmp) }
            }
        }
    }

    private fun makeThumb(f: StatusFile): Bitmap? {
        if (!f.isVideo) return decodeSampled(f.uri, 360)
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(this, f.uri)
            val frame = r.getFrameAtTime(100_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: r.getFrameAtTime(0L)
            if (frame == null) return null
            val side = maxOf(frame.width, frame.height)
            if (side <= 480) return frame
            val s = 480f / side
            return Bitmap.createScaledBitmap(frame, (frame.width * s).toInt(), (frame.height * s).toInt(), true)
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
                // egal
            }
        }
    }

    private fun decodeSampled(uri: Uri, target: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        val maxSide = maxOf(bounds.outWidth, bounds.outHeight)
        while (maxSide / (sample * 2) >= target) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }

    // ------------------------------------------------------------------ Hilfen

    private fun ageText(ms: Long): String {
        val m = ms / 60000
        if (m < 1) return "gerade eben"
        if (m < 60) return "vor $m Min."
        val h = m / 60
        if (h < 24) return "vor $h Std."
        val d = h / 24
        return if (d == 1L) "vor 1 Tag" else "vor $d Tagen"
    }

    private fun expiryText(ageMs: Long): String {
        val rem = 24 * 3600_000L - ageMs
        if (rem <= 0) return "Frist abgelaufen"
        if (rem < 3600_000L) return "noch ca. ${maxOf(1L, rem / 60000)} Min."
        return "noch ca. ${rem / 3600_000L} Std."
    }

    private fun sizeText(b: Long): String =
        if (b < 1048576L) "${maxOf(1L, b / 1024)} KB" else String.format(Locale.GERMANY, "%.1f MB", b / 1048576.0)

    // ------------------------------------------------------------------ Farben

    private fun brightness(c: Int): Float =
        (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f

    private fun blend(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    /** Leitet aus der Hintergrundfarbe passende Flächen- und Textfarben ab (hell oder dunkel). */
    private fun applyTheme(bg: Int) {
        BG = bg
        val dark = brightness(bg) < 0.5f
        INK = if (dark) Color.parseColor("#E7ECF2") else Color.parseColor("#111B26")
        val towards = if (dark) Color.WHITE else Color.BLACK
        SURFACE = blend(bg, towards, 0.07f)
        SURFACE2 = blend(bg, towards, 0.15f)
        MUTED = blend(INK, bg, 0.38f)
    }

    private fun showColorDialog() {
        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        var chosen = BG
        var syncing = false
        val preview = View(this)
        val bars = ArrayList<SeekBar>()

        fun paintPreview() {
            preview.background = GradientDrawable().apply {
                setColor(chosen)
                cornerRadius = dp(10).toFloat()
                setStroke(dp(1), MUTED)
            }
        }

        fun setColorTo(c: Int) {
            chosen = c
            syncing = true
            bars[0].progress = Color.red(c)
            bars[1].progress = Color.green(c)
            bars[2].progress = Color.blue(c)
            syncing = false
            paintPreview()
        }

        val names = listOf("Rot", "Grün", "Blau")
        for (n in names) {
            val sb = SeekBar(this)
            sb.max = 255
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (syncing) return
                    chosen = Color.rgb(bars[0].progress, bars[1].progress, bars[2].progress)
                    paintPreview()
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            bars.add(sb)
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(14))
            background = rounded(SURFACE, dp(16))
        }
        box.addView(text("Hintergrundfarbe", 18f, INK, true))
        box.addView(preview, LinearLayout.LayoutParams(MATCH, dp(44)).apply { topMargin = dp(12) })

        var row: LinearLayout? = null
        for ((i, c) in PRESETS.withIndex()) {
            if (i % 4 == 0) {
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                row = r
                box.addView(r, lp(8))
            }
            val sw = View(this)
            sw.background = GradientDrawable().apply {
                setColor(c)
                cornerRadius = dp(10).toFloat()
                setStroke(dp(1), MUTED)
            }
            sw.setOnClickListener { setColorTo(c) }
            row?.addView(sw, LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }

        box.addView(text("Eigene Farbe", 14f, MUTED), lp(14))
        for ((i, sb) in bars.withIndex()) {
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            r.addView(text(names[i], 13f, MUTED), LinearLayout.LayoutParams(dp(48), WRAP))
            r.addView(sb, LinearLayout.LayoutParams(0, WRAP, 1f))
            box.addView(r, lp(2))
        }

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(
            button("Abbrechen", false) { dlg.dismiss() },
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(8) }
        )
        actions.addView(
            button("Übernehmen", true) {
                prefs.edit().putInt("bg", chosen).apply()
                dlg.dismiss()
                recreate()
            },
            LinearLayout.LayoutParams(0, WRAP, 1f)
        )
        box.addView(actions, lp(16))

        setColorTo(BG)
        dlg.setContentView(box)
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dlg.show()
        dlg.window?.setLayout((resources.displayMetrics.widthPixels * 0.92).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun circle(fill: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(fill)
        setStroke(dp(2), Color.WHITE)
    }

    private fun lp(top: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(top) }

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun button(label: String, primary: Boolean, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(if (primary) Color.WHITE else INK)
            background = rounded(if (primary) ACCENT else SURFACE2, dp(10))
            setPadding(dp(14), dp(10), dp(14), dp(10))
            minHeight = dp(48)
            minimumHeight = dp(48)
            stateListAnimator = null
            setOnClickListener { onClick() }
        }

    private fun chip(label: String, index: Int): TextView =
        text(label, 14f, MUTED).apply {
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener {
                filter = index
                applyFilter()
            }
        }
}
