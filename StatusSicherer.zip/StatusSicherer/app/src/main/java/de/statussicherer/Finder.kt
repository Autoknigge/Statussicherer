package de.statussicherer

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.util.Locale

/** Eine Status-Datei (Bild oder Video), über die Ordnerfreigabe des Systems gefunden. */
data class StatusFile(
    val uri: Uri,
    val name: String,
    val size: Long,
    val modified: Long,
    val isVideo: Boolean,
    val source: String
) {
    val key: String get() = "$name|$size|$modified"
    val ext: String get() = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
}

object Finder {

    private val IMAGES = setOf("jpg", "jpeg", "png", "webp", "gif")
    private val VIDEOS = setOf("mp4", "3gp", "webm", "mkv")

    // Ordnernamen, in die bei einer Ordnerfreigabe hineingesucht wird.
    private val HINT_DIRS = setOf(
        "Android", "media", "com.whatsapp", "com.whatsapp.w4b",
        "WhatsApp", "WhatsApp Business", "Media"
    )

    /** Liefert "image", "video" oder null, wenn die Datei kein Status-Medium ist. */
    fun mediaType(name: String): String? {
        if (name.startsWith(".")) return null
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return when {
            ext in IMAGES -> "image"
            ext in VIDEOS -> "video"
            else -> null
        }
    }

    private fun labelFor(path: String): String =
        if (path.contains("w4b", ignoreCase = true) || path.contains("Business", ignoreCase = true)) {
            "WhatsApp Business"
        } else {
            "WhatsApp"
        }

    private class Child(
        val id: String,
        val name: String,
        val mime: String,
        val size: Long,
        val modified: Long
    ) {
        val isDir: Boolean get() = mime == DocumentsContract.Document.MIME_TYPE_DIR
    }

    private fun children(ctx: Context, tree: Uri, docId: String): List<Child> {
        val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )
        val out = ArrayList<Child>()
        ctx.contentResolver.query(uri, projection, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: ""
                val mime = c.getString(2) ?: ""
                out.add(Child(id, name, mime, c.getLong(3), c.getLong(4)))
            }
        }
        return out
    }

    private fun findStatusDirs(ctx: Context, tree: Uri, docId: String, depth: Int, out: MutableList<String>) {
        if (depth > 5) return
        for (c in children(ctx, tree, docId)) {
            if (!c.isDir) continue
            if (c.name == ".Statuses") {
                out.add(c.id)
            } else if (c.name in HINT_DIRS) {
                findStatusDirs(ctx, tree, c.id, depth + 1, out)
            }
        }
    }

    /** Ordnerfreigabe (Storage Access Framework): sucht ab der gewählten Stelle nach ".Statuses". */
    fun scanTree(ctx: Context, tree: Uri): List<StatusFile> {
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val dirs = ArrayList<String>()
        findStatusDirs(ctx, tree, rootId, 0, dirs)
        val targets: List<String> = if (dirs.isEmpty()) listOf(rootId) else dirs
        val out = ArrayList<StatusFile>()
        for (id in targets) {
            val label = labelFor(id)
            for (c in children(ctx, tree, id)) {
                if (c.isDir) continue
                val type = mediaType(c.name) ?: continue
                if (c.size == 0L) continue
                out.add(
                    StatusFile(
                        DocumentsContract.buildDocumentUriUsingTree(tree, c.id),
                        c.name, c.size, c.modified, type == "video", label
                    )
                )
            }
        }
        return out
    }
}
