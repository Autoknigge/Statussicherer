plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// AdMob-IDs von Status-Sicherer (öffentliche Kennungen, stehen in jeder APK).
// Überschreibbar per GitHub-Secrets ADMOB_APP_ID / ADMOB_BANNER_ID / ADMOB_OPEN_ID.
val admobAppId: String =
    (project.findProperty("ADMOB_APP_ID") as String?)?.takeIf { it.isNotBlank() }
        ?: "ca-app-pub-7178658520690671~6782036279"
val admobBannerId: String =
    (project.findProperty("ADMOB_BANNER_ID") as String?)?.takeIf { it.isNotBlank() }
        ?: "ca-app-pub-7178658520690671/4203974396"
val admobOpenId: String =
    (project.findProperty("ADMOB_OPEN_ID") as String?)?.takeIf { it.isNotBlank() }
        ?: "ca-app-pub-7178658520690671/5596947118"

android {
    namespace = "de.statussicherer"
    compileSdk = 36

    defaultConfig {
        applicationId = "de.statussicherer"
        minSdk = 30
        targetSdk = 36
        versionCode = (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0) + 100
        versionName = "2.0"

        manifestPlaceholders["admobAppId"] = admobAppId
        buildConfigField("String", "ADMOB_BANNER_ID", "\"$admobBannerId\"")
        buildConfigField("String", "ADMOB_OPEN_ID", "\"$admobOpenId\"")
    }

    buildFeatures {
        buildConfig = true
    }

    val keystoreFile = System.getenv("KEYSTORE_FILE")?.let { file(it) }
    val hasKey = keystoreFile != null && keystoreFile.exists()

    signingConfigs {
        if (hasKey) {
            create("fest") {
                storeFile = keystoreFile
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = "statussicherer"
                keyPassword = System.getenv("KEYSTORE_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Mit festem Schlüssel signieren, damit Updates über die alte App installierbar sind.
            signingConfig = if (hasKey) signingConfigs.getByName("fest") else signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("com.google.android.gms:play-services-ads:23.6.0")
}
